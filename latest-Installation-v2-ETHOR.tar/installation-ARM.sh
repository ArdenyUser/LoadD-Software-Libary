sudo apt install gcc make gcc-arm-linux-gnueabi binutils-arm-linux-gnueabi
