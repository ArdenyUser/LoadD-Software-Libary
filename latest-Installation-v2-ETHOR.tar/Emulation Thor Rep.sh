
echo  ____  ______ |                   |______  "
echo "|___     |   |_______  _______   |           "
echo "|        |   |       |  |      |  |          "
echo "|___     |   |       |  |      |  |        "
echo "                     |  |______|              "
echo  -------------------------------------------------------
echo  Welcome to the Emulation Thor Rep. This Rep contains a version of Emulation Thor that is
echo  customly modified to be used in this Rep for easy install. Contains lots of ArdenWareApps.
dialog --menu "Choose one:" 10 30 3 \
    1 Red \
    2 Green \
    3 ArdenWARE
