sudo apt install gcc make gcc-aarch64-linux-gnu binutils-aarch64-linux-gnu
sudo apt-get install qemu-user gcc-aarch64-linux-gnu
